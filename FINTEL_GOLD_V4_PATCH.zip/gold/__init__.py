"""FinTel Gold layer implementations."""
