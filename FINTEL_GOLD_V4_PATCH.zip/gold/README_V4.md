# FinTel Gold v4

Gold v4 is a separate implementation. It does not overwrite `gold_job.py`,
`gold_job_v2.py`, `gold_job_v3.py`, `main.py`, the Silver outputs, or the old
Gold checkpoints.

## Processing design

- Stock input: existing Delta folder at `Market_ticker/silver/data/stock_silver`.
- News input: existing immutable Silver batch files under
  `silver_news/data/silver/news_by_ticker`.
- `news_normalizer.py` watches the Silver news batches, reads them with
  pandas/PyArrow, converts timestamps to Parquet microseconds, and publishes
  normalized files to `data/gold_v4/news_stream_input`. Silver remains read-only.
- Spark runs three queries:
  1. completed stock windows -> `fintel_gold.gold_stock_metrics`;
  2. article-symbol news rows -> `fintel_gold.gold_news_sentiment`;
  3. event-time stream-stream inner join on symbol and the same window ->
     `fintel_gold.gold_sentiment_price` and `fintel_gold.gold_alerts`.
- The join uses the configured 5-minute window, 1-minute slide, and 10-minute
  watermark. A row in `gold_sentiment_price` means stock ticks and news were
  present for that symbol and exact event-time window. Stock windows without
  news are still stored in `gold_stock_metrics`; the dashboard should left-join
  those metrics to integrated rows when it needs a complete price timeline.
- Writes are schema-qualified, use psycopg 3, and upsert on the existing unique
  keys. Gold v4 has isolated checkpoints at `data/checkpoints/gold_v4`.
- The existing `gold_audit` table records per-query micro-batches.

## Run

From the project root, activate the existing root-level `gold_venv` and run:

```cmd
run_gold_v4.bat
```

Or manually:

```cmd
gold_venv\Scripts\activate
gold_venv\Scripts\python main_v4.py
```

The project-root `.env` must contain the PostgreSQL settings already configured
for this project, including `FINTEL_PG_ENABLED=1`, `FINTEL_PG_DB=fintel_db`,
and `FINTEL_PG_SCHEMA=fintel_gold`. Keep the password only in `.env`.

## Important behavior

- This is a fresh checkpoint lineage. The first run will read the existing
  Silver backlog as well as future appended data. It may take longer than later
  runs while the existing stock files are processed.
- `gold_sentiment_price` contains same-window news matches only; it does not
  carry old news forward. This avoids presenting stale articles as if they
  were contemporaneous with a stock movement.
- The dashboard has not yet been switched to PostgreSQL in this patch. Do that
  only after the Gold v4 tables contain verified rows.
- The first run is a functional integration test, not a claim that the
  stream-stream join has already been validated on the user's machine. Review
  Spark logs for query startup and micro-batch completion.
