@echo off
setlocal

title FinTel Gold v4 - PostgreSQL
cd /d "%~dp0"

echo ================================================
echo   FINTEL GOLD V4 - POSTGRESQL SERVING LAYER
echo ================================================
echo.

call gold_venv\Scripts\activate.bat
if errorlevel 1 (
    echo [ERROR] Could not activate gold_venv.
    pause
    exit /b 1
)

REM Gold v4 follows the project window specification.
set "FINTEL_WINDOW_DURATION=5 minutes"
set "FINTEL_SLIDE_DURATION=1 minute"
set "FINTEL_WATERMARK=10 minutes"
set "FINTEL_GOLD_TRIGGER=30 seconds"
set "FINTEL_GOLD_V4_MAX_FILES_PER_TRIGGER=1000"

REM Keep credentials in the root .env; do not put passwords in this file.
python main_v4.py

if errorlevel 1 (
    echo.
    echo [ERROR] Gold v4 stopped with an error. Review the logs above.
)

echo.
echo Gold v4 process ended.
pause
endlocal
